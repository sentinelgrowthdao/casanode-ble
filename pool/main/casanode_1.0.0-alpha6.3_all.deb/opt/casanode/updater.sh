#!/bin/bash
apt update && apt upgrade -y