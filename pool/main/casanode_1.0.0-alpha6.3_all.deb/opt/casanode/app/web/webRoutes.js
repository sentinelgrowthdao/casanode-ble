import express, { Router } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import QRCode from 'qrcode';
import config from '../utils/configuration.js';
import nodeManager from '../utils/node.js';
import { getLocalIPAddress } from '../utils/network.js';
import { Logger } from '../utils/logger.js';
// Create __dirname equivalent in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Create a new router
const webRouter = Router();
// Define the base directory
const baseDir = process.env.BASE_DIR || path.resolve(__dirname, '../../');
// Define the assets directory
const assetsDir = path.join(baseDir, 'web');
/**
 * Serve static files from the assets directory
 */
webRouter.use('/assets', express.static(assetsDir));
/**
 * Serve the index.html file
 */
webRouter.get('/', async (req, res) => {
    // Get node configuration
    const nodeConfig = nodeManager.getConfig();
    // Get local IP address
    const localIPAddress = getLocalIPAddress();
    // QR code data
    const qrData = {
        device: 'casanode',
        os: nodeConfig.systemOs,
        kernel: nodeConfig.systemKernel,
        architecture: nodeConfig.systemArch,
        ip: localIPAddress,
        webPort: config.WEB_LISTEN.split(':')[1] || 8080,
        apiPort: config.API_LISTEN.split(':')[1] || 8081,
        authToken: config.API_AUTH,
    };
    // If bluetooth is available and enabled
    if (config.BLE_ENABLED !== 'false') {
        qrData.bluetooth = {
            uuid: config.BLE_UUID,
            discovery: config.BLE_DISCOVERY_UUID,
            seed: config.BLE_CHARACTERISTIC_SEED,
        };
    }
    // Generate QR code data URL
    const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData));
    // Read the HTML file
    const htmlFilePath = path.join(assetsDir, 'index.html');
    // Read the HTML file
    fs.readFile(htmlFilePath, 'utf8', (err, html) => {
        // Send error if file could not be loaded
        if (err) {
            Logger.error('Error loading HTML file');
            res.status(500).send('Error loading HTML file');
            return;
        }
        Logger.info('Serving HTML file');
        // Replace the placeholder with the QR code data URL
        const modifiedHtml = html.replace('QR_CODE_DATA_URL', qrCodeDataURL);
        // Send the modified HTML file
        res.send(modifiedHtml);
    });
});
export default webRouter;
