import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import { vpnChangeType, } from '../utils/node.js';
export class VpnChangeTypeCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of VpnChangeTypeCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read'],
            onReadRequest: this.onReadRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        // Create the VPN configuration
        vpnChangeType().then((statusVpn) => {
            Logger.info(`VPN configuration file created: ${statusVpn}`);
            callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from('0'));
            return null;
        })
            .catch((error) => {
            Logger.error(`Error while creating the VPN configuration: ${error}`);
            callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR, Buffer.from('1'));
            return null;
        });
    }
}
