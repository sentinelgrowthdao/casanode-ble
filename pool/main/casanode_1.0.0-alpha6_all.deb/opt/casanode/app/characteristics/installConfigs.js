import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import { createNodeConfig, createVpnConfig, } from '../utils/node.js';
import { certificateGenerate } from '../utils/certificate.js';
var ConfigStatus;
(function (ConfigStatus) {
    ConfigStatus[ConfigStatus["NOT_STARTED"] = 0] = "NOT_STARTED";
    ConfigStatus[ConfigStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    ConfigStatus[ConfigStatus["COMPLETED"] = 2] = "COMPLETED";
    ConfigStatus[ConfigStatus["ERROR"] = -1] = "ERROR";
})(ConfigStatus || (ConfigStatus = {}));
export class InstallConfigsCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Configuration installation status
     * @type ConfigStatus
     */
    configStatus = ConfigStatus.NOT_STARTED;
    /**
     * Status summary of node, VPN, and certificate generation
     * @type string
     */
    statusSummary = '000'; // Default: Node(0), VPN(0), Cert(0)
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of InstallConfigsCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read', 'write'],
            onReadRequest: this.onReadRequest.bind(this),
            onWriteRequest: this.onWriteRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        let response;
        switch (this.configStatus) {
            case ConfigStatus.NOT_STARTED:
                response = '0';
                break;
            case ConfigStatus.IN_PROGRESS:
                response = '1';
                break;
            case ConfigStatus.ERROR:
                response = '-1';
                break;
            case ConfigStatus.COMPLETED:
                response = this.statusSummary;
                break;
        }
        Logger.info(`Configuration status: ${response}`);
        callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(response));
    }
    /**
     * Called when the characteristic is written to start the configuration installation process
     * @param data Buffer
     * @param offset number
     * @param withoutResponse boolean
     * @param callback (result: number) => void
     * @returns void
     */
    onWriteRequest(data, offset, withoutResponse, callback) {
        if (this.configStatus === ConfigStatus.IN_PROGRESS) {
            Logger.error('Configuration installation already in progress');
            callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR);
            return;
        }
        this.configStatus = ConfigStatus.IN_PROGRESS;
        callback(this.Bleno.Characteristic.RESULT_SUCCESS);
        Logger.info('Starting configuration installation process');
        // Start creating the node configuration
        createNodeConfig().then((statusNode) => {
            this.statusSummary = statusNode ? '1' : '0';
            // Start creating the VPN configuration
            return createVpnConfig();
        })
            .then((statusVpn) => {
            this.statusSummary += statusVpn ? '1' : '0';
            // Start generating the certificate
            return certificateGenerate();
        })
            .then((certSuccess) => {
            this.statusSummary += certSuccess ? '1' : '0';
            this.configStatus = ConfigStatus.COMPLETED;
            Logger.info(`Configuration installation completed with status: ${this.statusSummary}`);
            return null;
        })
            .catch((error) => {
            this.configStatus = ConfigStatus.ERROR;
            Logger.error(`Error during configuration installation: ${error}`);
            return null;
        });
    }
}
