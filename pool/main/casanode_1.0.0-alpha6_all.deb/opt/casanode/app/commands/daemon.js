import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import config from '../utils/configuration.js';
import WebServer from '../utils/web.js';
import { v5 as uuidv5 } from 'uuid';
import { loadingNodeInformations, loadingSystemInformations } from '../actions/startup.js';
import { isBluetoothAvailable } from '../utils/bluetooth.js';
import { DiscoveryCharacteristic } from '../characteristics/discovery.js';
import { MonikerCharacteristic } from '../characteristics/moniker.js';
import { NodeTypeCharacteristic } from '../characteristics/nodeType.js';
import { NodeIpCharacteristic } from '../characteristics/nodeIp.js';
import { NodePortCharacteristic } from '../characteristics/nodePort.js';
import { VpnTypeCharacteristic } from '../characteristics/vpnType.js';
import { VpnPortCharacteristic } from '../characteristics/vpnPort.js';
import { MaxPeersCharacteristic } from '../characteristics/maxPeers.js';
import { NodeConfigCharacteristic } from '../characteristics/nodeConfig.js';
import { NodeLocationCharacteristic } from '../characteristics/nodeLocation.js';
import { CertExpirityCharacteristic } from '../characteristics/certExpirity.js';
import { BandwidthSpeedCharacteristic } from '../characteristics/bandwidthSpeed.js';
import { SystemUptimeCharacteristic } from '../characteristics/systemUptime.js';
import { CasanodeVersionCharacteristic } from '../characteristics/casanodeVersion.js';
import { DockerImageCharacteristic } from '../characteristics/dockerImage.js';
import { SystemArchCharacteristic } from '../characteristics/systemArch.js';
import { SystemOsCharacteristic } from '../characteristics/systemOs.js';
import { SystemKernelCharacteristic } from '../characteristics/systemKernel.js';
import { NodePassphraseCharacteristic } from '../characteristics/nodePassphrase.js';
import { PublicAddressCharacteristic } from '../characteristics/publicAddress.js';
import { NodeAddressCharacteristic } from '../characteristics/nodeAddress.js';
import { NodeBalanceCharacteristic } from '../characteristics/nodeBalance.js';
import { NodeStatusCharacteristic } from '../characteristics/nodeStatus.js';
import { CheckInstallationCharacteristic } from '../characteristics/checkInstallation.js';
import { InstallDockerImageCharacteristic } from '../characteristics/installDockerImage.js';
import { InstallConfigsCharacteristic } from '../characteristics/installConfigs.js';
import { NodeActionsCharacteristic } from '../characteristics/nodeActions.js';
import { SystemActionsCharacteristic } from '../characteristics/systemActions.js';
import { CertificateActionsCharacteristic } from '../characteristics/certificateActions.js';
import { NodeMnemonicCharacteristic } from '../characteristics/nodeMnemonic.js';
import { WalletActionsCharacteristic } from '../characteristics/walletActions.js';
import { NodeKeyringBackendCharacteristic } from '../characteristics/nodeKeyringBackend.js';
import { OnlineUsersCharacteristic } from '../characteristics/onlineUsers.js';
import { VpnChangeTypeCharacteristic } from '../characteristics/vpnChangeConfig.js';
import { CheckPortCharacteristic } from '../characteristics/checkPort.js';
/**
 * Generate a UUID from a seed and a characteristic ID
 * @param characteristicId string
 * @returns string
 */
function generateUUIDFromSeed(characteristicId) {
    return uuidv5(`${config.BLE_CHARACTERISTIC_SEED}+${characteristicId}`, uuidv5.URL);
}
/**
 * Daemon command
 * @returns void
 */
export const daemonCommand = async () => {
    Logger.info('Daemon process started.');
    try {
        // Load system information
        await loadingSystemInformations();
        // Load node information
        await loadingNodeInformations();
        // Start the web server
        await startWebServer();
        // Start the Bluetooth service
        await startBluetooth();
    }
    catch (error) {
        Logger.error('An unexpected error occurred in daemon process.', error);
    }
};
/**
 * Start the web server
 * @returns void
 */
const startWebServer = async () => {
    try {
        Logger.info('Starting web server...');
        // Get the web server instance
        const webServer = WebServer.getInstance();
        // Initialize SSL and routes
        await webServer.init();
        // Start the web server
        webServer.start();
        Logger.info('Web server started successfully.');
    }
    catch (error) {
        Logger.error('Failed to start the web server.', error);
    }
};
/**
 * Start the Bluetooth service
 * @returns void
 */
const startBluetooth = async () => {
    try {
        // Check if Bluetooth is available
        const bluetoothAvailable = await isBluetoothAvailable();
        // If Bluetooth is not available, log a info and exit the initialization
        if (!bluetoothAvailable) {
            Logger.info('No Bluetooth controller found. Continuing without Bluetooth support.');
            return;
        }
        // Check if the Bluetooth is disabled
        if (config.BLE_ENABLED === 'false') {
            Logger.info('Bluetooth is disabled. Exiting Bluetooth initialization.');
            return;
        }
        // Dynamically import the Bleno module using CommonJS require
        const require = createRequire(import.meta.url);
        const bleno = require('bleno');
        // Create a new primary service with the UUID and characteristics
        const service = new bleno.PrimaryService({
            uuid: `${config.BLE_UUID}`,
            characteristics: [
                new DiscoveryCharacteristic(`${config.BLE_DISCOVERY_UUID}`).create(),
                new MonikerCharacteristic(generateUUIDFromSeed('moniker')).create(),
                new NodeTypeCharacteristic(generateUUIDFromSeed('node-type')).create(),
                new NodeIpCharacteristic(generateUUIDFromSeed('node-ip')).create(),
                new NodePortCharacteristic(generateUUIDFromSeed('node-port')).create(),
                new VpnTypeCharacteristic(generateUUIDFromSeed('vpn-type')).create(),
                new VpnPortCharacteristic(generateUUIDFromSeed('vpn-port')).create(),
                new MaxPeersCharacteristic(generateUUIDFromSeed('max-peers')).create(),
                new NodeConfigCharacteristic(generateUUIDFromSeed('node-config')).create(),
                new NodeLocationCharacteristic(generateUUIDFromSeed('node-location')).create(),
                new CertExpirityCharacteristic(generateUUIDFromSeed('cert-expirity')).create(),
                new BandwidthSpeedCharacteristic(generateUUIDFromSeed('bandwidth-speed')).create(),
                new SystemUptimeCharacteristic(generateUUIDFromSeed('system-uptime')).create(),
                new CasanodeVersionCharacteristic(generateUUIDFromSeed('casanode-version')).create(),
                new DockerImageCharacteristic(generateUUIDFromSeed('docker-image')).create(),
                new SystemArchCharacteristic(generateUUIDFromSeed('system-arch')).create(),
                new SystemOsCharacteristic(generateUUIDFromSeed('system-os')).create(),
                new SystemKernelCharacteristic(generateUUIDFromSeed('system-kernel')).create(),
                new NodePassphraseCharacteristic(generateUUIDFromSeed('node-passphrase')).create(),
                new PublicAddressCharacteristic(generateUUIDFromSeed('public-address')).create(),
                new NodeAddressCharacteristic(generateUUIDFromSeed('node-address')).create(),
                new NodeBalanceCharacteristic(generateUUIDFromSeed('node-balance')).create(),
                new NodeStatusCharacteristic(generateUUIDFromSeed('node-status')).create(),
                new CheckInstallationCharacteristic(generateUUIDFromSeed('check-installation')).create(),
                new InstallDockerImageCharacteristic(generateUUIDFromSeed('install-docker-image')).create(),
                new InstallConfigsCharacteristic(generateUUIDFromSeed('install-configs')).create(),
                new NodeActionsCharacteristic(generateUUIDFromSeed('node-actions')).create(),
                new SystemActionsCharacteristic(generateUUIDFromSeed('system-actions')).create(),
                new CertificateActionsCharacteristic(generateUUIDFromSeed('certificate-actions')).create(),
                new NodeMnemonicCharacteristic(generateUUIDFromSeed('node-mnemonic')).create(),
                new WalletActionsCharacteristic(generateUUIDFromSeed('wallet-actions')).create(),
                new NodeKeyringBackendCharacteristic(generateUUIDFromSeed('node-keyring-backend')).create(),
                new OnlineUsersCharacteristic(generateUUIDFromSeed('online-users')).create(),
                new VpnChangeTypeCharacteristic(generateUUIDFromSeed('vpn-change-type')).create(),
                new CheckPortCharacteristic(generateUUIDFromSeed('check-port')).create(),
            ]
        });
        /**
         * Event listener for the stateChange event
         * @param state string
         */
        bleno.on('stateChange', (state) => {
            // If the state is powered on, start advertising the service
            if (state === 'poweredOn') {
                Logger.info('Bluetooth powered on. Application started successfully.');
                bleno.startAdvertising('Casanode', [`${config.BLE_UUID}`]);
            }
            else {
                Logger.info('Bluetooth powered off. Stopping advertising.');
                bleno.stopAdvertising();
            }
        });
        /**
         * Event listener for the advertisingStart event
         * @param error any
         */
        bleno.on('advertisingStart', (error) => {
            if (!error) {
                Logger.info('Advertising...');
                // Set the services to be advertised
                bleno.setServices([service]);
            }
            else {
                Logger.error('Advertising failed: ' + error);
            }
        });
        Logger.info('Bluetooth initialized successfully.');
    }
    catch (error) {
        Logger.error('Failed to initialize Bluetooth.', error);
    }
};
