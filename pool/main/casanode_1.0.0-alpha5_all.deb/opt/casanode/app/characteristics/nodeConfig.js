import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import nodeManager from '../utils/node.js';
export class NodeConfigCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of NodeConfigCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['write'],
            onWriteRequest: this.onWriteRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is written
     * @param data Buffer
     * @param offset number
     * @param withoutResponse boolean
     * @param callback (result: number) => void
     * @returns void
     */
    onWriteRequest(data, offset, withoutResponse, callback) {
        // Get the value from the buffer
        const value = data.toString('utf-8').trim();
        // Check if the value is invalid
        if (value !== 'apply') {
            Logger.error('Invalid value received via Bluetooth for updating the node configuration.');
            callback(this.Bleno.Characteristic.RESULT_INVALID_ATTRIBUTE_LENGTH);
            return;
        }
        // Update the configuration
        nodeManager.refreshConfigFiles();
        // Notify the subscriber if the value is set
        callback(this.Bleno.Characteristic.RESULT_SUCCESS);
        Logger.info('Node configuration updated.');
    }
}
