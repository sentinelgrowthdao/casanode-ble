import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import nodeManager from '../utils/node.js';
export class VpnTypeCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of VpnTypeCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read', 'write'],
            onReadRequest: this.onReadRequest.bind(this),
            onWriteRequest: this.onWriteRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        // Get the value from the configuration
        const value = nodeManager.getConfig().vpn_type;
        // Return the value to the subscriber
        callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(value));
    }
    /**
     * Called when the characteristic is written
     * @param data Buffer
     * @param offset number
     * @param withoutResponse boolean
     * @param callback (result: number) => void
     * @returns void
     */
    onWriteRequest(data, offset, withoutResponse, callback) {
        // Get the value from the buffer
        const value = data.toString('utf-8').trim();
        // Check if the value is valid
        if (value !== 'wireguard' && value !== 'v2ray') {
            Logger.error('Invalid value received via Bluetooth for "vpn_type".');
            callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR);
            return;
        }
        // Set the value in the configuration
        nodeManager.setVpnType(value);
        // Notify the subscriber if the value is set
        callback(this.Bleno.Characteristic.RESULT_SUCCESS);
        Logger.info(`Parameter "vpn_type" updated via Bluetooth to: ${value}`);
    }
}
