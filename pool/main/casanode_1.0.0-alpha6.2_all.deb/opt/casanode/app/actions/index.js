export * from './checkInstallation.js';
